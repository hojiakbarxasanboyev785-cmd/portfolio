        // ==================== MA'LUMOTLAR ====================
        const yolBelgilari = [
            // Ogohlantirish belgilari
            { id: 1, kategoriya: 'ogohlantirish', rasm: 'fas fa-triangle-exclamation', nomi: 'Xavfli burilish', manosi: 'Oldinda xavfli burilish', qollanilishi: 'Xavfli burilishlardan oldin' },
            { id: 2, kategoriya: 'ogohlantirish', rasm: 'fas fa-road', nomi: 'Sirpanchiq yo\'l', manosi: 'Yo\'lning sirpanchiq qismi', qollanilishi: 'Muzlagan yo\'llarda' },
            { id: 3, kategoriya: 'ogohlantirish', rasm: 'fas fa-child', nomi: 'Bolalar', manosi: 'Bolalar o\'ynashi mumkin', qollanilishi: 'Maktablar yonida' },
            { id: 4, kategoriya: 'ogohlantirish', rasm: 'fas fa-person-walking', nomi: 'Piyodalar o\'tish joyi', manosi: 'Piyodalar o\'tishi mumkin', qollanilishi: 'Piyodalar o\'tish joylarida' },
            { id: 5, kategoriya: 'ogohlantirish', rasm: 'fas fa-bicycle', nomi: 'Velosiped yo\'li', manosi: 'Velosipedchilar chiqishi mumkin', qollanilishi: 'Velosiped yo\'llari kesishmasida' },
            
            // Taqiqlovchi belgilar
            { id: 6, kategoriya: 'taqiqlovchi', rasm: 'fas fa-circle-exclamation', nomi: 'Kirish taqiqlangan', manosi: 'Barcha transport vositalarining kirishi taqiqlangan', qollanilishi: 'Bir tomonlama yo\'llarda' },
            { id: 7, kategoriya: 'taqiqlovchi', rasm: 'fas fa-car', nomi: 'Avtomobillar harakati taqiqlangan', manosi: 'Avtomobillarning harakati taqiqlangan', qollanilishi: 'Piyodalar zonalarida' },
            { id: 8, kategoriya: 'taqiqlovchi', rasm: 'fas fa-gauge-high', nomi: 'Tezlik chegarasi 60 km/soat', manosi: 'Maksimal tezlik 60 km/soat', qollanilishi: 'Shaharlararo yo\'llarda' },
            { id: 9, kategoriya: 'taqiqlovchi', rasm: 'fas fa-clock', nomi: 'To\'xtash taqiqlangan', manosi: 'Transport vositalarini to\'xtatish taqiqlangan', qollanilishi: 'Tor yo\'llarda' },
            { id: 10, kategoriya: 'taqiqlovchi', rasm: 'fas fa-octagon', nomi: 'STOP', manosi: 'To\'liq to\'xtash shart', qollanilishi: 'Kesishmalarda' },
            
            // Buyruq belgilari
            { id: 11, kategoriya: 'buyruq', rasm: 'fas fa-arrow-right', nomi: 'Faqat o\'ngga', manosi: 'Faqat o\'ngga burilishga ruxsat', qollanilishi: 'Kesishmalarda' },
            { id: 12, kategoriya: 'buyruq', rasm: 'fas fa-arrow-left', nomi: 'Faqat chapga', manosi: 'Faqat chapga burilishga ruxsat', qollanilishi: 'Kesishmalarda' },
            { id: 13, kategoriya: 'buyruq', rasm: 'fas fa-arrow-up', nomi: 'Faqat to\'g\'riga', manosi: 'Faqat to\'g\'riga harakatlanish', qollanilishi: 'Yo\'nalishlarda' },
            
            // Axborot belgilari
            { id: 14, kategoriya: 'axborot', rasm: 'fas fa-road', nomi: 'Avtomobil yo\'li', manosi: 'Avtomobil yo\'lining boshlanishi', qollanilishi: 'Avtomobil yo\'llarida' },
            { id: 15, kategoriya: 'axborot', rasm: 'fas fa-parking', nomi: 'To\'xtash joyi', manosi: 'Transport vositalarini to\'xtatish joyi', qollanilishi: 'To\'xtash joylarida' },
            { id: 16, kategoriya: 'axborot', rasm: 'fas fa-bus', nomi: 'Avtobus bekati', manosi: 'Avtobus to\'xtash joyi', qollanilishi: 'Avtobus bekatlarida' },
            
            // Xizmat belgilari
            { id: 17, kategoriya: 'xizmat', rasm: 'fas fa-gas-pump', nomi: 'Yoqilg\'i quyish', manosi: 'Yoqilg\'i quyish shoxobchasi', qollanilishi: 'Yoqilg\'i quyish shoxobchalarida' },
            { id: 18, kategoriya: 'xizmat', rasm: 'fas fa-utensils', nomi: 'Ovqatlanish', manosi: 'Kafe yoki restoran', qollanilishi: 'Ovqatlanish shoxobchalarida' },
            { id: 19, kategoriya: 'xizmat', rasm: 'fas fa-hotel', nomi: 'Mehmonxona', manosi: 'Mehmonxona yoki motel', qollanilishi: 'Mehmonxonalar yonida' },
            { id: 20, kategoriya: 'xizmat', rasm: 'fas fa-hospital', nomi: 'Kasalxona', manosi: 'Kasalxona yoki tibbiy yordam', qollanilishi: 'Kasalxonalar yonida' }
        ];

        // Test savollari
        const testSavollari = [
            { id: 1, savol: "Qaysi belgi 'Xavfli burilish' ma'nosini bildiradi?", variantlar: ["Qizil doira", "Sariq uchburchak", "Ko'k kvadrat", "Sakkizburchak"], togri: 1, izoh: "Ogohlantirish belgilari sariq uchburchak shaklida bo'ladi." },
            { id: 2, savol: "STOP belgisi qanday shaklda?", variantlar: ["Qizil doira", "Sariq uchburchak", "Qizil sakkizburchak", "Ko'k to'rtburchak"], togri: 2, izoh: "STOP belgisi sakkizburchak shaklida." },
            { id: 3, savol: "Piyodalar o'tish joyi qanday belgi bilan ko'rsatiladi?", variantlar: ["Qizil doira", "Sariq uchburchak", "Ko'k kvadrat", "Sakkizburchak"], togri: 1, izoh: "Piyodalar o'tish joyi - sariq uchburchak." },
            { id: 4, savol: "Tezlik chegarasi 60 km/soat belgisi qanday?", variantlar: ["Qizil doira ichida 60", "Ko'k doira ichida 60", "Sariq uchburchak ichida 60", "Yashil to'rtburchak ichida 60"], togri: 0, izoh: "Tezlik chegarasi qizil doira ichida." },
            { id: 5, savol: "Kirish taqiqlangan belgisi qanday?", variantlar: ["Qizil doira", "Sariq uchburchak", "Ko'k kvadrat", "Sakkizburchak"], togri: 0, izoh: "Kirish taqiqlangan - qizil doira." },
            { id: 6, savol: "Faqat o'ngga belgisi qanday?", variantlar: ["Ko'k doira ichida o'ng strelka", "Qizil doira ichida o'ng strelka", "Sariq uchburchak ichida strelka", "Sakkizburchak"], togri: 0, izoh: "Buyruq belgilari ko'k doira ichida." },
            { id: 7, savol: "Qizil svetafor signali nima ma'noni bildiradi?", variantlar: ["Harakatlanish mumkin", "To'xtash kerak", "Diqqatli bo'lish", "Tezlikni oshirish"], togri: 1, izoh: "Qizil svetafor - to'xtash." },
            { id: 8, savol: "Temir yo'l kesishmasiga yaqinlashganda nima qilish kerak?", variantlar: ["Tezlikni oshirish", "Tezlikni kamaytirish", "Signal berish", "To'xtamasdan o'tish"], togri: 1, izoh: "Tezlikni kamaytirish kerak." }
        ];

        // Imtihon savollari
        const imtihonSavollari = testSavollari.slice(0, 5); // 5 ta savol (test uchun)

        // ==================== STATE ====================
        let currentSection = 'menu';
        let currentTestIndex = 0;
        let testScore = 0;
        let selectedAnswer = null;
        let testAnswered = false;
        let currentKategoriya = 'all';
        let currentSearch = '';
        
        // Imtihon state
        let imtihonMode = false;
        let imtihonIndex = 0;
        let imtihonJavoblar = new Array(imtihonSavollari.length).fill(null);
        let imtihonTimer = null;
        let imtihonVaqt = 300; // 5 daqiqa (test uchun)
        let imtihonTugadi = false;
        
        // Statistika
        let statistika = {
            testIshlangan: 0,
            togriJavoblar: 0,
            imtihonUrinishlar: 0,
            imtihonOtilgan: 0
        };

        // ==================== NAVIGATION ====================
        function showSection(section) {
            currentSection = section;
            
            // Update nav buttons
            document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.nav-btn').forEach(btn => {
                if(btn.textContent.includes(section === 'menu' ? 'Asosiy' : 
                    section === 'belgilar' ? 'Yo\'l' :
                    section === 'test' ? 'Cheksiz' :
                    section === 'imtihon' ? 'Imtihon' : 'Statistika')) {
                    btn.classList.add('active');
                }
            });
            
            // Show section
            document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
            document.getElementById(section + '-section').classList.add('active');
            
            // Render section
            if(section === 'belgilar') renderBelgilar();
            if(section === 'test') resetTest();
            if(section === 'imtihon') resetImtihon();
            if(section === 'statistika') renderStatistika();
            
            updateProgress();
        }

        // ==================== YO'L BELGILARI ====================
        function renderBelgilar() {
            const grid = document.getElementById('belgilarGrid');
            let filtered = yolBelgilari;
            
            if(currentKategoriya !== 'all') {
                filtered = yolBelgilari.filter(b => b.kategoriya === currentKategoriya);
            }
            
            if(currentSearch) {
                filtered = filtered.filter(b => 
                    b.nomi.toLowerCase().includes(currentSearch.toLowerCase())
                );
            }
            
            let html = '';
            filtered.forEach(belgi => {
                html += `
                    <div class="belgi-card" onclick="showBelgiInfo(${belgi.id})">
                        <div class="belgi-rasm">
                            <i class="${belgi.rasm}"></i>
                        </div>
                        <div class="belgi-nomi">${belgi.nomi}</div>
                        <span class="belgi-kategoriya">${belgi.kategoriya}</span>
                    </div>
                `;
            });
            
            grid.innerHTML = html;
        }

        function filterBelgilar() {
            currentSearch = document.getElementById('belgiSearch').value;
            renderBelgilar();
        }

        function filterBelgiKategoriya(kategoriya) {
            currentKategoriya = kategoriya;
            
            document.querySelectorAll('.cat-btn').forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            renderBelgilar();
        }

        function showBelgiInfo(id) {
            const belgi = yolBelgilari.find(b => b.id === id);
            
            document.getElementById('modalIcon').innerHTML = `<i class="${belgi.rasm}"></i>`;
            document.getElementById('modalTitle').textContent = belgi.nomi;
            document.getElementById('modalText').innerHTML = `
                <strong>Ma'nosi:</strong> ${belgi.manosi}<br><br>
                <strong>Qo'llanilishi:</strong> ${belgi.qollanilishi}<br><br>
                <strong>Kategoriya:</strong> ${belgi.kategoriya}
            `;
            
            document.getElementById('infoModal').classList.add('active');
        }

        function closeModal() {
            document.getElementById('infoModal').classList.remove('active');
        }

        // ==================== TEST ====================
        function resetTest() {
            currentTestIndex = 0;
            testScore = 0;
            selectedAnswer = null;
            testAnswered = false;
            renderTest();
        }

        function renderTest() {
            const container = document.getElementById('testContainer');
            const savol = testSavollari[currentTestIndex];
            
            let variantlarHtml = '';
            savol.variantlar.forEach((variant, index) => {
                let variantClass = 'variant';
                let icon = 'far fa-circle';
                
                if (testAnswered) {
                    if (index === savol.togri) {
                        variantClass += ' correct';
                        icon = 'fas fa-check-circle';
                    } else if (selectedAnswer === index) {
                        variantClass += ' wrong';
                        icon = 'fas fa-times-circle';
                    }
                } else if (selectedAnswer === index) {
                    variantClass += ' selected';
                    icon = 'fas fa-dot-circle';
                }
                
                variantlarHtml += `
                    <div class="${variantClass}" onclick="selectAnswer(${index})">
                        <i class="${icon}"></i>
                        ${variant}
                    </div>
                `;
            });
            
            container.innerHTML = `
                <div class="test-header">
                    <span class="savol-raqam">
                        <i class="fas fa-question"></i> Savol ${currentTestIndex + 1}/${testSavollari.length}
                    </span>
                    <span class="ball">
                        <i class="fas fa-star"></i> Ball: ${testScore}
                    </span>
                </div>
                
                <div class="savol-matin">
                    ${savol.savol}
                </div>
                
                <div class="variantlar">
                    ${variantlarHtml}
                </div>
                
                ${testAnswered ? `
                    <div style="background: #f0f4f8; padding: 20px; border-radius: 16px; margin-bottom: 20px;">
                        <i class="fas fa-lightbulb" style="color: #f59e0b;"></i>
                        ${savol.izoh}
                    </div>
                    <button class="tekshirish-btn" onclick="nextQuestion()">
                        <i class="fas fa-arrow-right"></i>
                        ${currentTestIndex < testSavollari.length - 1 ? 'Keyingi savol' : 'Yakunlash'}
                    </button>
                ` : `
                    <button class="tekshirish-btn" onclick="checkAnswer()" ${selectedAnswer === null ? 'disabled' : ''}>
                        <i class="fas fa-check"></i>
                        Javobni tekshirish
                    </button>
                `}
            `;
        }

        function selectAnswer(index) {
            if (testAnswered) return;
            selectedAnswer = index;
            renderTest();
        }

        function checkAnswer() {
            if (selectedAnswer === null) return;
            
            const savol = testSavollari[currentTestIndex];
            if (selectedAnswer === savol.togri) {
                testScore += 5;
                statistika.togriJavoblar++;
            }
            
            testAnswered = true;
            statistika.testIshlangan++;
            renderTest();
            updateProgress();
        }

        function nextQuestion() {
            if (currentTestIndex < testSavollari.length - 1) {
                currentTestIndex++;
                selectedAnswer = null;
                testAnswered = false;
                renderTest();
            } else {
                showModal('Test yakunlandi!', `Siz ${testScore} ball to'pladingiz`);
                showSection('menu');
            }
            updateProgress();
        }

        // ==================== IMTIHON ====================
        function resetImtihon() {
            imtihonIndex = 0;
            imtihonJavoblar = new Array(imtihonSavollari.length).fill(null);
            imtihonVaqt = 300; // 5 daqiqa
            imtihonTugadi = false;
            statistika.imtihonUrinishlar++;
            
            if (imtihonTimer) clearInterval(imtihonTimer);
            imtihonTimer = setInterval(updateTimer, 1000);
            
            renderImtihon();
        }

        function updateTimer() {
            if (imtihonTugadi) return;
            
            imtihonVaqt--;
            if (imtihonVaqt <= 0) {
                imtihonVaqt = 0;
                finishImtihon();
            }
            
            renderImtihon();
        }

        function renderImtihon() {
            const container = document.getElementById('imtihonContainer');
            
            if (imtihonTugadi) {
                const togri = imtihonJavoblar.filter((j, i) => j === imtihonSavollari[i].togri).length;
                const ball = togri * 5;
                const otdi = togri >= 4; // 5 savoldan 4+ to'g'ri
                
                if(otdi) statistika.imtihonOtilgan++;
                
                container.innerHTML = `
                    <div class="result-card">
                        <div class="result-icon">${otdi ? '🎉' : '😔'}</div>
                        <div class="result-title">${otdi ? 'Tabriklaymiz!' : 'Qayta urinib ko\'ring'}</div>
                        <div class="result-score">${togri}/${imtihonSavollari.length}</div>
                        <p>${ball} ball</p>
                        <p style="margin: 20px 0;">${otdi ? 'Siz imtihondan o\'tdingiz!' : 'O\'tish uchun kamida 4 ta to\'g\'ri javob kerak'}</p>
                        <button class="tekshirish-btn" onclick="resetImtihon()">Qayta boshlash</button>
                    </div>
                `;
                return;
            }
            
            const savol = imtihonSavollari[imtihonIndex];
            const javob = imtihonJavoblar[imtihonIndex];
            
            const minutes = Math.floor(imtihonVaqt / 60);
            const seconds = imtihonVaqt % 60;
            
            let variantlarHtml = '';
            savol.variantlar.forEach((variant, index) => {
                let variantClass = 'variant';
                let icon = 'far fa-circle';
                
                if (javob !== null) {
                    if (index === savol.togri) {
                        variantClass += ' correct';
                        icon = 'fas fa-check-circle';
                    } else if (javob === index) {
                        variantClass += ' wrong';
                        icon = 'fas fa-times-circle';
                    }
                } else if (javob === index) {
                    variantClass += ' selected';
                    icon = 'fas fa-dot-circle';
                }
                
                variantlarHtml += `
                    <div class="${variantClass}" onclick="${javob === null ? `selectImtihonJavob(${index})` : ''}">
                        <i class="${icon}"></i>
                        ${variant}
                    </div>
                `;
            });
            
            container.innerHTML = `
                <div class="imtihon-header">
                    <div class="timer">${minutes}:${seconds.toString().padStart(2, '0')}</div>
                    <div class="imtihon-stats">
                        <div class="stat-box">${imtihonIndex + 1}/${imtihonSavollari.length}</div>
                        <div class="stat-box">${imtihonJavoblar.filter(j => j !== null).length} javob</div>
                        <div class="stat-box">${imtihonSavollari.length - imtihonJavoblar.filter(j => j !== null).length} qoldi</div>
                    </div>
                </div>
                
                <div class="savol-matin">${savol.savol}</div>
                
                <div class="variantlar">${variantlarHtml}</div>
                
                <div class="nav-buttons">
                    <button class="nav-btn-small" onclick="prevImtihon()" ${imtihonIndex === 0 ? 'disabled' : ''}>
                        <i class="fas fa-arrow-left"></i> Oldingi
                    </button>
                    <button class="nav-btn-small" onclick="nextImtihon()" ${imtihonIndex === imtihonSavollari.length - 1 ? 'disabled' : ''}>
                        Keyingi <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
                
                <button class="finish-btn" onclick="finishImtihon()">
                    <i class="fas fa-flag-checkered"></i> Yakunlash
                </button>
            `;
        }

        function selectImtihonJavob(index) {
            if (imtihonTugadi) return;
            imtihonJavoblar[imtihonIndex] = index;
            renderImtihon();
            updateProgress();
        }

        function prevImtihon() {
            if (imtihonIndex > 0) {
                imtihonIndex--;
                renderImtihon();
            }
        }

        function nextImtihon() {
            if (imtihonIndex < imtihonSavollari.length - 1) {
                imtihonIndex++;
                renderImtihon();
            }
        }

        function finishImtihon() {
            imtihonTugadi = true;
            if (imtihonTimer) {
                clearInterval(imtihonTimer);
                imtihonTimer = null;
            }
            renderImtihon();
            updateProgress();
        }

        // ==================== STATISTIKA ====================
        function renderStatistika() {
            const container = document.getElementById('statistikaContainer');
            
            container.innerHTML = `
                <div class="stats-grid">
                    <div class="stats-card">
                        <i class="fas fa-pen-to-square" style="font-size: 40px; color: #0b2b5c; margin-bottom: 15px;"></i>
                        <div class="stats-number">${statistika.testIshlangan}</div>
                        <div>Ishlangan testlar</div>
                    </div>
                    
                    <div class="stats-card">
                        <i class="fas fa-check-circle" style="font-size: 40px; color: #10b981; margin-bottom: 15px;"></i>
                        <div class="stats-number">${statistika.togriJavoblar}</div>
                        <div>To'g'ri javoblar</div>
                    </div>
                    
                    <div class="stats-card">
                        <i class="fas fa-graduation-cap" style="font-size: 40px; color: #f59e0b; margin-bottom: 15px;"></i>
                        <div class="stats-number">${statistika.imtihonUrinishlar}</div>
                        <div>Imtihon urinishlar</div>
                    </div>
                    
                    <div class="stats-card">
                        <i class="fas fa-trophy" style="font-size: 40px; color: #ffd700; margin-bottom: 15px;"></i>
                        <div class="stats-number">${statistika.imtihonOtilgan}</div>
                        <div>Muvaffaqiyatli</div>
                    </div>
                </div>
            `;
        }

        // ==================== UMUMIY ====================
        function updateProgress() {
            let progress = 0;
            
            if(currentSection === 'belgilar') {
                progress = 50;
            } else if(currentSection === 'test') {
                progress = ((currentTestIndex + 1) / testSavollari.length) * 100;
            } else if(currentSection === 'imtihon') {
                const answered = imtihonJavoblar.filter(j => j !== null).length;
                progress = (answered / imtihonSavollari.length) * 100;
            }
            
            document.getElementById('progressText').textContent = Math.round(progress) + '%';
        }

        function showModal(title, text) {
            document.getElementById('modalIcon').innerHTML = '🎉';
            document.getElementById('modalTitle').textContent = title;
            document.getElementById('modalText').textContent = text;
            document.getElementById('infoModal').classList.add('active');
            
            setTimeout(() => {
                document.getElementById('infoModal').classList.remove('active');
            }, 3000);
        }

        // ==================== INIT ====================
        document.addEventListener('DOMContentLoaded', function() {
            renderBelgilar();
        });